package com.vinsguru.sec12;

public enum UserRole {

    STANDARD,
    PRIME;

}
