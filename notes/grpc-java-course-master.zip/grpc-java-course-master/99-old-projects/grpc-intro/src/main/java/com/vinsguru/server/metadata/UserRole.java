package com.vinsguru.server.metadata;

public enum UserRole {
    PRIME,
    STANDARD;
}
