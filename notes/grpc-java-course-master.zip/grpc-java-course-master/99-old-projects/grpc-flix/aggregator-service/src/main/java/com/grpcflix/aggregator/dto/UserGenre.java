package com.grpcflix.aggregator.dto;

import lombok.Data;

@Data
public class UserGenre {

    private String loginId;
    private String genre;

}
