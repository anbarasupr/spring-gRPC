# Running Stock Service

```bash
java -jar stock-service.jar
```

## Changing the port
```bash
java -jar stock-service.jar --grpc.server.port=7576
```