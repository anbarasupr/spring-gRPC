package com.vinsguru.aggregator.dto;

public record PriceUpdateDto(String ticker,
                             Integer price) {
}
