package com.vinsguru.user.tests;

public class UserServiceTest {



}
