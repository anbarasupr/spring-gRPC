package com.vinsguru.aggregator.tests;

public class UserTradeTest {


}
